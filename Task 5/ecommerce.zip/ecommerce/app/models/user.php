<?php 
namespace app\models;

use app\database\connection;
use app\database\contracts\crud;

//include '../../vendor/autoload.php';
class User extends connection implements crud{
    private $id,$first_name,$last_name,$email,$password,$phone,$gender,$image,
    $status,$remember_token,$email_verified_at,$vertification_code,
    $code_expired_at,$created_at,$updated_at;
    

    /**
     * Get the value of id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of first_name
     */
    public function getFirstName()
    {
        return $this->first_name;
    }

    /**
     * Set the value of first_name
     */
    public function setFirstName($first_name): self
    {
        $this->first_name = $first_name;

        return $this;
    }

    /**
     * Get the value of last_name
     */
    public function getLastName()
    {
        return $this->last_name;
    }

    /**
     * Set the value of last_name
     */
    public function setLastName($last_name): self
    {
        $this->last_name = $last_name;

        return $this;
    }

    /**
     * Get the value of email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     */
    public function setEmail($email): self
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of password
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set the value of password
     */
    public function setPassword($password): self
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get the value of phone
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set the value of phone
     */
    public function setPhone($phone): self
    {
        $this->phone = $phone;

        return $this;
    }

    /**
     * Get the value of gender
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * Set the value of gender
     */
    public function setGender($gender): self
    {
        $this->gender = $gender;

        return $this;
    }

    /**
     * Get the value of image
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set the value of image
     */
    public function setImage($image): self
    {
        $this->image = $image;

        return $this;
    }

    /**
     * Get the value of status
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set the value of status
     */
    public function setStatus($status): self
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get the value of remember_token
     */
    public function getRememberToken()
    {
        return $this->remember_token;
    }

    /**
     * Set the value of remember_token
     */
    public function setRememberToken($remember_token): self
    {
        $this->remember_token = $remember_token;

        return $this;
    }

    /**
     * Get the value of email_verified_at
     */
    public function getEmailVerifiedAt()
    {
        return $this->email_verified_at;
    }

    /**
     * Set the value of email_verified_at
     */
    public function setEmailVerifiedAt($email_verified_at): self
    {
        $this->email_verified_at = $email_verified_at;

        return $this;
    }

    /**
     * Get the value of vertification_code
     */
    public function getVerificationCode()
    {
        return $this->vertification_code;
    }

    /**
     * Set the value of vertification_code
     */
    public function setVerificationCode($vertification_code): self
    {
        $this->vertification_code = $vertification_code;

        return $this;
    }

    /**
     * Get the value of code_expired_at
     */
    public function getCodeExpiredAt()
    {
        return $this->code_expired_at;
    }

    /**
     * Set the value of code_expired_at
     */
    public function setCodeExpiredAt($code_expired_at): self
    {
        $this->code_expired_at = $code_expired_at;

        return $this;
    }

    /**
     * Get the value of created_at
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * Set the value of created_at
     */
    public function setCreatedAt($created_at): self
    {
        $this->created_at = $created_at;

        return $this;
    }

    /**
     * Get the value of updated_at
     */
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }

    /**
     * Set the value of updated_at
     */
    public function setUpdatedAt($updated_at): self
    {
        $this->updated_at = $updated_at;

        return $this;
    }

    //from crud.php
   public function creat(){

   }
   public function read(){

   }
    public function update(){

    }
    public function delete(){

    }
}
<?php
namespace app\requests;
class RegisterRequest
{
    private $password;
    private $password_confirmation;
    private $email;
    private $phone;

    /**
     * Get the value of password
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set the value of password
     */
    public function setPassword($password): self
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get the value of password_confirmation
     */
    public function getPasswordConfirmation()
    {
        return $this->password_confirmation;
    }

    /**
     * Set the value of password_confirmation
     */
    public function setPasswordConfirmation($password_confirmation): self
    {
        $this->password_confirmation = $password_confirmation;

        return $this;
    }

    /**
     * Get the value of email
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set the value of email
     */
    public function setEmail($email): self
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get the value of phone
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * Set the value of phone
     */
    public function setPhone($phone): self
    {
        $this->phone = $phone;

        return $this;
    }
    public function passwordValidation()
    {
        if (empty($this->password)) {
        }
        else{
            if (preg_match('//',$this->password)){
                        
            }
        }
    }
}

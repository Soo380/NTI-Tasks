<?php
 namespace app\database\contracts;
 interface crud{
    function creat();
    function read();
    function update();
    function delete();
 }
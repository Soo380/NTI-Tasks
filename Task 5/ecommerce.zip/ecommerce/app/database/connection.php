<?php
namespace app\database;

use mysqli;

    class connection{
        private $hostname = 'localhost';
        private $username = 'root';
        private $password = '';
        private $database = 'ecommerce';
        protected $con;
        public function __construct(){
            $this->con=new mysqli($this->hostname,$this->username,$this->password,$this->database);
    //     //     if($this->con->connect_error){
    //     //         die('connection failed :' . $this->con->connect_error);
    //     //     }
    //     //     echo "connection successfully";
    //      }
    }
        //new connection;
    //DML(INSERT-UPDATE-DELETE)
        public function runDML($qyery): bool {
            $result=$this->con->query($qyery);
            if($result){
                return true;
            }else{
                return false;
            }
        }
    //DQL(SELECT)
        public function runDQL($qyery) {
            return $this->con->query($qyery);
        
        }

        public function __destruct()
        {
        // $this->con = null;
            $this->con->close();
        }
}
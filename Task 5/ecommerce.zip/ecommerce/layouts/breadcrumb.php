 <!-- Breadcrumb Area Start -->
 <div class="breadcrumb-area bg-image-3 ptb-150">
     <div class="container">
         <div class="breadcrumb-content text-center">
             <h3><?= $title ?></h3>
             <ul>
                 <li><a href="index.php">Home</a></li>
                 <li class="active"><?= $title ?></li>
             </ul>
         </div>
     </div>
 </div>
 <!-- Breadcrumb Area End -->